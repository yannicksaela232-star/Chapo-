package com.vipshop.ussd;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/* Visual próprio: preto, dourado e cartões com contorno fino. */
public class UI {
    static final int OURO = Color.parseColor("#22C55E");
    static final int FUNDO = Color.parseColor("#0B1220");
    static final int CARTAO_FUNDO = Color.parseColor("#111827");
    static final int BARRA = Color.parseColor("#0F172A");
    static final int CINZA = Color.parseColor("#94A3B8");
    static final int VERDE = Color.parseColor("#22C55E");
    static final int VERMELHO = Color.parseColor("#EF4444");

    static int dp(Context c, int d) {
        return (int) (d * c.getResources().getDisplayMetrics().density);
    }

    static LinearLayout cartao(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARTAO_FUNDO);
        g.setCornerRadius(dp(c, 16));
        g.setStroke(dp(c, 1), Color.parseColor("#1F2937"));
        l.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, 12), 0, 0);
        l.setLayoutParams(lp);
        return l;
    }

    static TextView texto(Context c, String t, int sp, int cor) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(cor);
        v.setPadding(0, dp(c, 3), 0, dp(c, 3));
        return v;
    }

    static Button botao(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(OURO);
        g.setCornerRadius(dp(c, 12));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(c, 12), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    static void estiloNav(Context c, Button b, boolean ativo) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(c, 12));
        g.setColor(ativo ? Color.parseColor("#14532D") : BARRA);
        b.setBackground(g);
        b.setTextColor(ativo ? OURO : CINZA);
        b.setAllCaps(false);
        b.setTextSize(12);
    }

    static String tempoRestante(Context c) {
        String a = Config.licencaAte(c);
        if (a.isEmpty()) return "sem acesso";
        if (a.equalsIgnoreCase("permanente")) return "acesso permanente";
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date fim = f.parse(a.substring(0, 19));
            long ms = fim.getTime() - System.currentTimeMillis();
            if (ms <= 0) return "expirado";
            long min = ms / 60000;
            return (min / 1440) + " d " + ((min % 1440) / 60) + " h " + (min % 60) + " min";
        } catch (Exception e) {
            return "—";
        }
    }
}
