package com.vipshop.ussd;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.provider.Settings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;

/* Sistema: aparelho, licença, servidor e token. */
public class SistemaView extends ScrollView {
    public SistemaView(Context c) {
        super(c);
        setBackgroundColor(Color.BLACK);
        LinearLayout corpo = new LinearLayout(c);
        corpo.setOrientation(LinearLayout.VERTICAL);
        corpo.setPadding(UI.dp(c, 20), UI.dp(c, 12), UI.dp(c, 20), UI.dp(c, 20));
        addView(corpo);

        corpo.addView(UI.texto(c, "Sistema", 20, UI.OURO));

        LinearLayout perfil = UI.cartao(c);
        perfil.addView(UI.texto(c, "ID do aparelho", 11, UI.CINZA));
        String id = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        perfil.addView(UI.texto(c, id == null ? "-" : id, 14, Color.WHITE));
        perfil.addView(UI.texto(c, "Licença", 11, UI.CINZA));
        perfil.addView(UI.texto(c, UI.tempoRestante(c), 16, UI.VERDE));
        perfil.addView(UI.texto(c, "Servidor", 11, UI.CINZA));
        perfil.addView(UI.texto(c, Config.servidor(c), 13, Color.WHITE));
        perfil.addView(UI.texto(c, "Token", 11, UI.CINZA));
        boolean tem = !Config.token(c).isEmpty();
        perfil.addView(UI.texto(c, tem ? "Definido" : "Em falta", 13, tem ? UI.VERDE : UI.VERMELHO));
        corpo.addView(perfil);

        boolean acess = acessibilidadeAtiva(c);
        perfil.addView(UI.texto(c, "Acessibilidade (leitura do marcador)", 11, UI.CINZA));
        perfil.addView(UI.texto(c, acess ? "Ativa" : "Inativa", 13, acess ? UI.VERDE : UI.VERMELHO));
        Button ab = UI.botao(c, "ABRIR ACESSIBILIDADE");
        ab.setOnClickListener(v -> c.startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        corpo.addView(ab);

        LinearLayout funcao = UI.cartao(c);
        funcao.addView(UI.texto(c, "🧭 Função deste telefone", 15, Color.WHITE));
        funcao.addView(UI.texto(c, "Atual: " + Papeis.nome(c), 13, UI.VERDE));
        String[][] opcoes = {{"📤 TELEFONE DE TRANSFERÊNCIA", Papeis.TRANSFERENCIA},
                {"💳 TELEFONE DE PAGAMENTO", Papeis.PAGAMENTO},
                {"🧩 TELEFONE ÚNICO (TUDO)", Papeis.UNICO}};
        for (String[] op : opcoes) {
            Button ob = UI.botao(c, op[0]);
            ob.setOnClickListener(v -> {
                Papeis.definir(c, op[1]);
                ((android.app.Activity) c).recreate();
            });
            funcao.addView(ob);
        }
        corpo.addView(funcao);

        LinearLayout ativ = UI.cartao(c);
        ativ.addView(UI.texto(c, "🔑 Ativar este telefone", 15, Color.WHITE));
        ativ.addView(UI.texto(c, "Cola a chave do telefone (VIP-D-...). Cada chave só funciona uma vez.", 12, UI.CINZA));
        final EditText chaveDisp = new EditText(c);
        chaveDisp.setHint("VIP-D-...");
        chaveDisp.setTextColor(Color.WHITE);
        chaveDisp.setHintTextColor(Color.parseColor("#666666"));
        ativ.addView(chaveDisp);
        final TextView estadoDisp = UI.texto(c, "", 13, UI.CINZA);
        Button bDisp = UI.botao(c, "🔑 ATIVAR TELEFONE");
        bDisp.setOnClickListener(v -> ativarDispositivo(c, chaveDisp.getText().toString().trim(), estadoDisp));
        ativ.addView(bDisp);
        ativ.addView(estadoDisp);
        corpo.addView(ativ);

        Button b = UI.botao(c, "COLAR TOKEN");
        b.setOnClickListener(v -> pedirToken(c));
        corpo.addView(b);
    }

    static boolean acessibilidadeAtiva(Context c) {
        String ativos = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return ativos != null && ativos.contains(c.getPackageName() + "/" + Acessibilidade.class.getName());
    }

    private void ativarDispositivo(Context c, String chave, TextView e) {
        if (!chave.startsWith("VIP-")) { e.setText("A chave começa por VIP-."); return; }
        e.setText("A ativar...");
        final String deviceId = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ANDROID_ID);
        final android.app.Activity act = (android.app.Activity) c;
        new Thread(() -> {
            try {
                JSONObject o = new JSONObject(Api.pedir(c, "POST", "/app/ativar", chave + " " + deviceId));
                if (o.optBoolean("ok") && "dispositivo".equals(o.optString("tipo"))) {
                    Config.p(c).edit()
                            .putString("token_disp", o.optString("token"))
                            .putString("papel", o.optString("papel"))
                            .apply();
                    act.runOnUiThread(act::recreate);
                } else {
                    String msg = o.optString("erro", "chave inválida");
                    act.runOnUiThread(() -> e.setText("Erro: " + msg));
                }
            } catch (Exception ex) {
                String msg = ex.getMessage() == null ? "erro" : ex.getMessage();
                act.runOnUiThread(() -> e.setText("Erro: " + msg));
            }
        }).start();
    }

    private void pedirToken(Context c) {
        final EditText t = new EditText(c);
        t.setHint("Token do servidor");
        t.setText(Config.token(c));
        new AlertDialog.Builder(c)
                .setTitle("Token do servidor")
                .setView(t)
                .setPositiveButton("GUARDAR", (d, w) ->
                        Config.p(c).edit().putString("token", t.getText().toString().trim()).apply())
                .setNegativeButton("CANCELAR", null)
                .show();
    }
}
