package com.vipshop.ussd;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/* Com acesso: topo com VIP BOT e tempo de uso, capa, conteúdo e separadores em baixo.
   Sem acesso: ecrã de ativação. */
public class MainActivity extends Activity {
    private static final String[] NOMES = {"🏠 INÍCIO", "📤 ENVIAR", "📦 FILA", "📊 LUCRO", "💳 PAGAM.", "👥 GRUPOS", "⚙️ SISTEMA"};
    private FrameLayout raiz;
    private FrameLayout corpo;
    private TextView tempoView;
    private final Button[] navBtn = new Button[NOMES.length];
    private int aba = 0;
    private EditText campo;
    private TextView estadoAcesso;
    private final Handler relogio = new Handler(Looper.getMainLooper());
    private final Runnable atualizarTempo = new Runnable() {
        @Override
        public void run() {
            if (tempoView != null) tempoView.setText(UI.tempoRestante(MainActivity.this));
            relogio.postDelayed(this, 60000);
        }
    };

    @Override
    protected void onCreate(Bundle guardado) {
        super.onCreate(guardado);
        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(UI.FUNDO);
        setContentView(raiz);
        pedirPermissoes();
    }

    private void pedirPermissoes() {
        java.util.ArrayList<String> falta = new java.util.ArrayList<>();
        String[] todas = {android.Manifest.permission.RECEIVE_SMS, android.Manifest.permission.CALL_PHONE,
                android.Manifest.permission.READ_PHONE_STATE};
        for (String p : todas) {
            if (checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) falta.add(p);
        }
        if (!falta.isEmpty()) requestPermissions(falta.toArray(new String[0]), 1);
        else iniciarServico();
    }

    private void iniciarServico() {
        if (!Config.pronto(this)) return;
        Intent i = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    @Override
    public void onRequestPermissionsResult(int codigo, String[] permissoes, int[] resultados) {
        super.onRequestPermissionsResult(codigo, permissoes, resultados);
        if (codigo == 1) iniciarServico();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mostrarTela();
        relogio.post(atualizarTempo);
    }

    @Override
    protected void onPause() {
        super.onPause();
        relogio.removeCallbacks(atualizarTempo);
    }

    private void mostrarTela() {
        raiz.removeAllViews();
        ImageView fundo = new ImageView(this);
        fundo.setImageResource(R.drawable.capa_vip);
        fundo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        raiz.addView(fundo, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        tempoView = null;
        if (Config.licencaAtiva(this)) raiz.addView(construirPrincipal());
        else raiz.addView(construirAcesso());
    }

    private LinearLayout construirPrincipal() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);

        LinearLayout topo = new LinearLayout(this);
        topo.setOrientation(LinearLayout.HORIZONTAL);
        topo.setGravity(Gravity.CENTER_VERTICAL);
        int p = UI.dp(this, 20);
        topo.setPadding(p, UI.dp(this, 28), p, UI.dp(this, 8));

        LinearLayout esq = new LinearLayout(this);
        esq.setOrientation(LinearLayout.VERTICAL);
        TextView marca = UI.texto(this, "VIP BOT AUTO", 20, UI.OURO);
        marca.setTypeface(null, Typeface.BOLD);
        marca.setOnLongClickListener(x -> { pedirToken(); return true; });
        esq.addView(marca);
        esq.addView(UI.texto(this, "Tempo de uso", 11, UI.CINZA));
        topo.addView(esq, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        tempoView = UI.texto(this, UI.tempoRestante(this), 14, UI.VERDE);
        topo.addView(tempoView);

        v.addView(topo);


        corpo = new FrameLayout(this);
        v.addView(corpo, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(UI.BARRA);
        int q = UI.dp(this, 10);
        nav.setPadding(q, q, q, q);
        for (int i = 0; i < NOMES.length; i++) {
            final int k = i;
            Button b = new Button(this);
            b.setText(NOMES[i]);
            b.setOnClickListener(x -> { aba = k; mostrarAba(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(UI.dp(this, 3), 0, UI.dp(this, 3), 0);
            b.setLayoutParams(lp);
            navBtn[i] = b;
            nav.addView(b);
        }
        v.addView(nav);

        for (int i = 0; i < NOMES.length; i++) {
            if (!Papeis.permite(this, i)) navBtn[i].setVisibility(View.GONE);
        }
        if (!Papeis.permite(this, aba)) aba = Papeis.primeira(this);
        mostrarAba();
        return v;
    }

    private void mostrarAba() {
        corpo.removeAllViews();
        switch (aba) {
            case 0: corpo.addView(new PainelView(this)); break;
            case 1: corpo.addView(new EnvioView(this)); break;
            case 2: corpo.addView(new FilaView(this)); break;
            case 3: corpo.addView(new EstatisticasView(this)); break;
            case 4: corpo.addView(new ComprovView(this)); break;
            case 5: corpo.addView(new GruposView(this)); break;
            default: corpo.addView(new SistemaView(this)); break;
        }
        if (corpo.getChildCount() > 0) corpo.getChildAt(0).setBackgroundColor(android.graphics.Color.TRANSPARENT);
        for (int i = 0; i < NOMES.length; i++) UI.estiloNav(this, navBtn[i], i == aba);
    }

    private void pedirToken() {
        final android.widget.EditText t = new android.widget.EditText(this);
        t.setHint("Token do servidor");
        t.setText(Config.token(this));
        new android.app.AlertDialog.Builder(this)
                .setTitle("Token do servidor")
                .setView(t)
                .setPositiveButton("GUARDAR", (d, w) -> {
                    Config.p(this).edit().putString("token", t.getText().toString().trim()).apply();
                    mostrarTela();
                })
                .setNegativeButton("CANCELAR", null)
                .show();
    }

    private ImageView capa(int alturaDp) {
        ImageView img = new ImageView(this);
        img.setImageResource(R.drawable.capa_vip);
        img.setScaleType(ImageView.ScaleType.FIT_XY);
        img.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, UI.dp(this, alturaDp)));
        return img;
    }

    private LinearLayout construirAcesso() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(UI.dp(this, 20), UI.dp(this, 28), UI.dp(this, 20), UI.dp(this, 24));

        TextView marca = UI.texto(this, "VIP BOT AUTO", 20, UI.OURO);
        marca.setTypeface(null, Typeface.BOLD);
        v.addView(marca);
        v.addView(UI.texto(this, "Sem acesso ativo", 11, UI.CINZA));


        LinearLayout cartao = UI.cartao(this);
        String ate = Config.licencaAte(this);
        cartao.addView(UI.texto(this, !ate.isEmpty() ? "A assinatura expirou" : "Ativa o acesso", 16, Color.WHITE));
        cartao.addView(UI.texto(this, "Escreve o código de acesso (VIP-...) ou um pedido (ex: VIP).", 13, UI.CINZA));

        campo = new EditText(this);
        campo.setHint("Código ou pedido");
        campo.setTextColor(Color.WHITE);
        campo.setHintTextColor(Color.parseColor("#666666"));
        cartao.addView(campo);

        Button b = UI.botao(this, "PEDIR ACESSO");
        b.setOnClickListener(x -> enviarAcesso());
        cartao.addView(b);

        estadoAcesso = UI.texto(this, "", 13, UI.CINZA);
        cartao.addView(estadoAcesso);
        v.addView(cartao);
        return v;
    }

    private void enviarAcesso() {
        final String t = campo.getText().toString().trim();
        if (t.isEmpty()) {
            estadoAcesso.setText("Escreve primeiro o código ou o pedido.");
            return;
        }
        estadoAcesso.setText("A enviar...");
        new Thread(() -> {
            try {
                if (t.toUpperCase().startsWith("VIP-")) {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/ativar", t));
                    if (o.optBoolean("ok")) {
                        Config.guardarLicenca(this, o.optString("validade"));
                        runOnUiThread(this::mostrarTela);
                    } else {
                        mostrarErro("Não foi possível: " + o.optString("erro"));
                    }
                } else {
                    JSONObject o = new JSONObject(Api.pedir(this, "POST", "/app/pedir", t));
                    mostrarErro(o.optBoolean("ok")
                            ? "Pedido enviado. Aguarde a aprovação. ID: " + o.optString("id")
                            : "Não foi possível enviar o pedido.");
                }
            } catch (Exception e) {
                mostrarErro("Sem ligação ao servidor. Tenta de novo.");
            }
        }).start();
    }

    private void mostrarErro(String t) {
        runOnUiThread(() -> estadoAcesso.setText(t));
    }
}
